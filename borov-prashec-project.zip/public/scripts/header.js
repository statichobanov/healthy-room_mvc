$('.header-wrapper').hover(() => {
    $('.header-wrapper').children('img').stop(true,true).fadeOut();
}, () => {
    $('.header-wrapper').children('img').fadeIn();
});

  