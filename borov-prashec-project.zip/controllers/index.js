const home = require('./home');

module.exports = {
  home: home,
};