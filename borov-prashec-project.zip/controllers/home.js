const database = require('../config/database');

module.exports = (req, res) => {

    const db = database.getDb();
    let emails;
    
    db.db().collection('HealthyRoom.emails').find({}).toArray((err, items) => {
        console.log(items);
        emails = items;
        res.render('home', { emails: emails});
    });
   
}