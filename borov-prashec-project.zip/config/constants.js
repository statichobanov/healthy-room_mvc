module.exports = {
    dbConnectionURL: "mongodb+srv://admin:addmin@cluster0.mongodb.net/HealthyRoom",
}