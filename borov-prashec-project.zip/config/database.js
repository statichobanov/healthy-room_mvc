const { MongoClient } = require('mongodb');
const connection = require('./constants').dbConnectionURL;
// eslint-disable-next-line no-underscore-dangle
let _db;

module.exports = {
  connectToServer(callback) {
    MongoClient.connect(connection, { useNewUrlParser: true }, (err, db) => {
      _db = db;
      return callback(err);
    });
  },
  getDb() {
    return _db;
  },
};